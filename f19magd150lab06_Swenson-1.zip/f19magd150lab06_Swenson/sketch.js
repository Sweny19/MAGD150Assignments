var ball = {
  x: 250,
  y: 250,
  xspeed: 5,
  yspeed: 3,
}
var r=0.0;
var theta=0;

function setup() {
  createCanvas(500, 500);
  background(50);
}

function draw() {
  noStroke();
  
  slide();
  
  //to keep the graphics within the canvas
  bounce();
  
  dragsquare(250, 250, 100);
  
  bubble(mouseX, mouseY, 100);
  
  bubble2(mouseX, mouseY, 50);
  
  push()
  fill(15,175,150,30);
  rotate(theta);
  rect(0,0,50,50);
  pop()
 
  //allows the rectangle and ellipse to rotate at a certain speed
  theta+=0.01;
  
  r+=0.2;
  if(r>20){
    r=0;
  }
    function mousePressed() {
  background(0);
}



function slide() {
  ball.x = ball.x + ball.xspeed;
  ball.y = ball.y + ball.xspeed;
}

function bounce(x, y) {
  if (ball.x > width || ball.x < 0) {
    ball.xspeed = ball.xspeed * -1;
  }
  if (ball.y > width || ball.y < 0) {
    ball.yspeed = ball.yspeed * -1;
  }
}

function dragsquare(x, y, diameter) {
  noStroke();
  fill(255, 5);
  rect(ball.x, ball.y, 600, 600);

  fill(150, 0, 25, 30);
  ellipse(ball.x, ball.y, diameter, diameter);
}

  //to keep the ellipse away from my mouse
function bubble(x, y, diameter) {
  translate(x,y)
   rotate(theta);
  fill(250, 0, 150, 30);
  ellipse(mouseX, mouseY, diameter, diameter);
}

  //to scale the bubble and shoot out from mouse
function bubble2(mouseX, mouseY, diameter) {
  push();
  scale(r)
  fill(250, 0, 100);
  ellipse(mouseX, mouseY, diameter, diameter);
  pop()
}
}


