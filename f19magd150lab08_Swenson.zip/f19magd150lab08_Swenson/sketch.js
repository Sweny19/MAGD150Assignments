words = ["This", "is", "a", "poster", "and", "this", "poster", "is", "my", "work"];
var x;
var index = 0;
var f;
var fs;
var pdf;

function setup() {
  createCanvas(500, 800);
  pos1 = createVector(0, 0);
  pos2 = createVector(500, 800);
  //This is a notepad document with words used to change the center text.
lines = loadStrings("Words.txt");
  pdf = createPDF();
  pdf.beginRecord();
  f = loadFont("BAUHS93.ttf");
  fs = loadFont("manoe10.ttf");
  x = width;
}

function draw() {
  background(220);
  loadFont(f);
  //The bottom line allows me to move my 2 vector lines to where my mouse is, witht he intention of creating a page flip type effect.
  var mouse = createVector(mouseX, mouseY);
  var pos1 = createVector(0,0);
  var pos2 = createVector(500,800);
  
  //These are the lines that make up 2 vectors that are always connected wherever my mouse goes.
  stroke(0);
  strokeWeight(3);
  line(0,0, mouse.x, mouse.y);
  line(500,800, mouse.x, mouse.y);
  
  //I loaded this font to stand out from the changing text in the center.
  loadFont(f);
  fill(0);
  textSize(100);
   textAlign(CENTER, TOP);
  text("Poster",width/2,100);
  
  loadFont(fs);
  fill(random(50,200));
  textSize(40);
text(words[index], width-250, height-400);
  
  //This allows the center body of text to change its words.
  x = x - 100
  
  let w = textWidth(words[index]);
  if(x < -w){
    x = width;
    
    index = (index + 1) % words.length;
  }
}
function mousePressed(){
pdf.save();
}

