var offset = 0;
var pizzatime=false;
function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(100);

   if (mousePressed){
    fill(255);
    textSize(80);
    text("CLICK HERE!",0,250);
  } else {
    noFill();
    textSize(0);
    text();
  }
  
 if (pizzatime){
   tri();
   }
}
 
//makes the pizza apear
 function mousePressed() {
  pizzatime =!pizzatime;  
  }
 
//all create the function to make the pizza appear
  function tri() {
    if (mousePressed);
    fill(250, 250, 0);
    noStroke();
    triangle(100, 100, 400, 100, 250, 425);

     //below line is the red circles
   for (var x = 0; x<= width; x+= 100) {
  for (var y = 0; y <= height; y += 100){ 
    noStroke();
    fill(255, 0, 0);
    ellipse(x + offset, y + offset, 55, 50);
    
    fill(100);
    rect(250,50,500,100);
    
    quad(0, 100, 100, 100, 285, 500, 0, 500);
    
    quad(500, 100, 400, 100, 215, 500, 500, 500);
    
   fill(200, 150, 0);
  rectMode(CENTER);
  rect(250, 100, 325, 75, 90);
    
     if (keyIsPressed) {
    fill(255,150,0);
    textSize(80);
    text("PIZZA",140, 127);
  } else {
    fill(255);
    textSize(40)
    text("PIZZA", 190, 115);
      }
    
  }
     offset = offset + 0.03;
  }
  }
