let angle = 0;
let img;
let capture;

function setup() {
  createCanvas(500, 500, WEBGL);
  createElement('h1','Space Donut Hole Game Thingy');
  img = loadImage('Neb.jpg');
  capture = createCapture(VIDEO);
  capture.size(320, 240);
}

function draw() {
  background(120);
  
  let locX = mouseX - height/2;
  let locY = mouseY - width/2;
  
  
  ambientLight(200, 200, 50);
  
    push();
  image(capture, -150, -150, 300, 300);
  rotateZ(angle * 0.005)
  pop();
  
  push();
  pointLight( 255, 255, 255, locX, locY, 100);
  fill(255);
  noStroke();
  fill(75, 0, 255);
  specularMaterial(175, 0, 105);
  translate(0,0, -125);
  rotateZ(angle * 0.005);
  rect(-350, -350, 700, 700);
  pop();
  

  
  push();
  ambientLight(200);
  ambientMaterial(50, 0, 150);
  stroke(0);
  rotateY(angle * 0.05);
  rotateZ(angle * 0.05);
  beginShape();
  vertex(50, 50);
  vertex(450, 50);
  vertex(450, 450);
  vertex(50, 450);
  endShape(CLOSE);
  pop();
  
  push();
  texture(img);
  noStroke();
  translate(mouseX - width/2, mouseY - height/2, 100);
  rotateX(angle * 0.1);
  rotateZ(angle * 0.1);
  sphere(50);
  pop();
  
   push();
  noStroke();
  translate(0, 0, 100);
  pointLight(255, 255, 255, locX, locY, 100);
  normalMaterial();
  rotateY(angle * 0.1);
  torus(100, 30, 24, 16)
  pop();
  
  angle += 0.5;
  
  camera(0, 0, 1000+sin(frameCount * 0.1) * 10, 0, 0, 0, 0, 1, 0);
  plane(100, 100);
}


