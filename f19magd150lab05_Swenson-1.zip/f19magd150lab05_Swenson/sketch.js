 
var rectX, rectY;   
var circleX, circleY;  
var rectSize = 90;    
var circleSize = 93;   
var rectColor, circleColor, baseColor;
var rectHighlight, circleHighlight;
var currentColor;
var rectOver = false;
var circleOver = false;

function setup() {
   x=75;
  y=60;
  yspeed=3;
  createCanvas(500, 500);
  rectColor = color(0);
  rectHighlight = color(55);
  circleColor = color(255);
  circleHighlight = color(200);
  baseColor = color(150);
  currentColor = baseColor;
  circleX = 130;
  circleY = 410;
  rectX = 325;
  rectY = 365;
}

function draw() {
  update(mouseX, mouseY);
  background(currentColor);
  
  noStroke();
  fill(0)
  rect(50,50, 400,275);
  
  if (rectOver) {
    fill(rectHighlight);
  } else {
    fill(rectColor);
  }
  stroke(255);
  rect(rectX, rectY, rectSize, rectSize);
  
  if (circleOver) {
    fill(circleHighlight);
  } else {
    fill(circleColor);
  }
  stroke(0);
  ellipse(circleX, circleY, circleSize, circleSize);
  
  fill(255);
   ellipse(x,y,50,50);
  y++;
   y+= yspeed;
  
    
  if(y-25>262.5){
    y=60;
    x = x+10;
    
}
  fill(255);
  text("BUTTON 2", 340, 415);
  
  fill(0);
  text("BUTTON 1", 100, 415);
  
}

function update( x,  y) {
  if ( overCircle(circleX, circleY, circleSize) ) {
    circleOver = true;
    rectOver = false;
  } else if ( overRect(rectX, rectY, rectSize, rectSize) ) {
    rectOver = true;
    circleOver = false;
  } else {
    circleOver = rectOver = false;
  }
}

function mousePressed() {
  if (circleOver) {
    currentColor = circleColor;
  }
  if (rectOver) {
    currentColor = rectColor;
  }
}
function overRect( x,  y,  width,  height)  {
  if (mouseX >= x && mouseX <= x+width && 
      mouseY >= y && mouseY <= y+height) {
    return true;
  } else {
    return false;
  }
}

function overCircle( x,  y,  diameter) {
  var disX = x - mouseX;
  var disY = y - mouseY;
  if (sqrt(sq(disX) + sq(disY)) < diameter/2 ) {
    return true;
  } else {
    return false;
  }
}
